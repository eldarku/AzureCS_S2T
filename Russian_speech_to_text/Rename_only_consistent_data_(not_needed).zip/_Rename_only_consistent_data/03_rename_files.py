import shutil
import os
import sys
import zipfile
import fileinput
import re


dirroot = "D:\\temp"
dirinput = dirroot+"\\input"
dirdata = dirroot+"\\data"
dirextract = dirroot+"\\data_extr"
dirtrain=dirroot+"\\train"

if not os.path.exists(dirtrain):
    os.mkdir(dirtrain)


fobj = open(dirtrain+"\\"+"_label.txt", "w", encoding="utf-8-sig")


for root, dirs, files in os.walk(dirextract):
    for file in files:
        if file.split(".")[1]== "wav":
            #print(file)
            spl = root.split("\\") 
            _=shutil.move(root+"\\"+file, dirtrain+"\\"+spl[len(dirroot.split("\\"))+1].replace(" ","_")+"_"+file)
        if file.split(".")[1]== "txt":
            
            spl = root.split("\\")
            #print(file)
            for line in fileinput.input(root+"\\"+file, openhook=fileinput.hook_encoded("utf-8"), inplace=False):
                #replace existing lines sampleNN.wav with author's name
                line = re.sub(r"(sample[0-9]{1,3}\.wav)",spl[len(dirroot.split("\\"))+1].replace(" ","_")+"_"+r"\1",line)
                line = re.sub(r"(\	[0-9]{1,3}\. )",r"	",line)
                _=fobj.write(line)
            fileinput.close()

fobj.close()
