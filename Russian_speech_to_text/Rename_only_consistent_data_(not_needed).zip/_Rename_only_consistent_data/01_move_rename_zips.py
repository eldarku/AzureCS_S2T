import shutil
import os
import sys


dirroot = "D:\\temp"
dirinput = dirroot+"\\input"
#Asilla Duisembaeva - extract manually
dirdata = dirroot+"\\data"
filename="data.zip"
if not os.path.exists(dirdata):
    os.mkdir(dirdata)

for root, dirs, files in os.walk(dirinput):
    for file in files:
        if file == filename:
            
            spl = root.split("\\")
            print(spl[len(dirroot.split("\\"))+1])
            
            shutil.move(root+"\\"+file, dirdata+"\\"+spl[len(dirroot.split("\\"))+1]+".zip")
 
            


