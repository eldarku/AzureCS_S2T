import shutil
import os
import sys
import zipfile


dirroot = "D:\\temp"
dirinput = dirroot+"\\input"
dirdata = dirroot+"\\data"
dirextract = dirroot+"\\data_extr"

if not os.path.exists(dirextract):
    os.mkdir(dirextract)


for root, dirs, files in os.walk(dirdata):
    for file in files:
        if file.split(".")[1]== "zip":
            print(file)
            
            try:
                with zipfile.ZipFile(dirdata+"\\"+file, 'r') as zip_ref:
                    zip_ref.extractall(dirextract+"\\"+file.split(".")[0])
                if not os.path.exists(dirextract+"\\"+file.split(".")[0]):
                    os.makedirs(dirextract+"\\"+file.split(".")[0])
            except Exception as exc:
                print(exc)
                pass

